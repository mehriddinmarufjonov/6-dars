from django.db import models

class construction(models.Model):
    area = models.CharField(max_length=200)

    def __str__(self):
        return f'{self.area}'
    
    
class organization(models.Model):
    construction = models.ForeignKey(construction, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    description  = models.TextField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.name}'
    

class building(models.Model):
    arorganizationea = models.ForeignKey(organization, on_delete=models.CASCADE)
    construction = models.ForeignKey(construction, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    floor = models.IntegerField()
    lift = models.BooleanField()


    def __str__(self):
        return f'{self.name}'