from rest_framework import serializers

from .models import construction, organization, building


class constructionSerializers(serializers.ModelSerializer):
    class Meta:
        model = construction
        fields = '__all__'


class organizationSerializers(serializers.ModelSerializer):
    class Meta:
        model = organization
        fields = '__all__'


class buildingSerializers(serializers.ModelSerializer):
    class Meta:
        model = building
        fields = '__all__'